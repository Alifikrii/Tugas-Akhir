"""CTGAN testing module."""
